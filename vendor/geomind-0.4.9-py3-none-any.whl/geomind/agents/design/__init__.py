"""Agents that propose configurations."""

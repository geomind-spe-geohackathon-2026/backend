"""The engine runs one agent until it stops; loops decide which run comes next.

Finite, like gemini's engine: it never sleeps or schedules itself. NOTE: unlike gemini it is
``async``, because parallel tools, streaming and the FastAPI backend need it and changing that
later would touch every layer. ``Run`` is the sync facade.
"""

from geomind import runtime
from geomind.engine.delegation import answer_child, end_orphans
from geomind.engine.log import RunLog
from geomind.engine.partial import is_limit_stop, partial_answer
from geomind.engine.permissions import Permissions
from geomind.engine.recovery import agent_class, recover
from geomind.engine.replay import replay_run
from geomind.engine.session import RunSession
from geomind.engine.state import RunState, Stop
from geomind.engine.step import record_result, run_step, settle_interrupted, text_result
from geomind.errors import NotImplementedYet, RequestError, RunError
from geomind.providers import with_retries
from geomind.stores.run import MemoryRunStore
from geomind.types import RunResult, Usage, status_of, validate_answer
from geomind.types.events import PermissionDecided, RunFinished, ToolRecorded
from geomind.utils.hooks import RemovableHandle


def run_result(session, stop):
    """Return the result of a stop."""
    state = session.state
    return RunResult(
        run_id=state.run_id,
        status=status_of(stop.reason),
        answer=stop.answer,
        request=stop.request,
        usage=state.usage,
        steps=state.step,
        stop_reason=stop.reason,
        message=None if stop.is_crash else stop.message,
    )


class Engine:
    """Drives one agent over steps, with one log for the run and its nested runs.

    ``callbacks``, ``hooks``, ``permissions`` and ``sandbox`` are as agreed. NOTE: ``llm``,
    ``store`` and ``workspace`` are added keywords, since a run needs them and they are not
    arguments of ``run``. The ``recorded*`` attributes are used by replay, each keyed by run id:
    ``recorded`` and ``recorded_changes`` by run, then (step, call id), ``recorded_llms`` by run id,
    and ``recorded_children`` by the parent run id, step and task of a nested run, to its run id.
    ``reuses_tools`` makes a replay keep the result of every pure tool.
    """

    def __init__(
        self,
        callbacks=None,
        hooks=None,
        permissions=None,
        sandbox=None,
        *,
        llm=None,
        store=None,
        workspace=None,
    ):
        """Keep what a run needs; ``llm`` gets the retry layer."""
        self.callbacks = list(callbacks or ())
        self._hooks = {}
        for hook in hooks or ():
            self.register_hook(hook)
        self.permissions = permissions or Permissions()
        self.sandbox = sandbox
        self.llm = with_retries(llm) if llm is not None else None
        self.store = store if store is not None else MemoryRunStore()
        self.workspace = workspace
        self.recorded = {}
        self.recorded_changes = {}
        self.recorded_children = {}
        self.recorded_llms = {}
        self.reuses_tools = False
        self._sequences = {}
        self._usages = {}

    def register_hook(self, hook):
        """Add a hook; the returned handle has ``.remove()``."""
        return RemovableHandle(self._hooks, hook)

    def hooks(self):
        """Return the registered hooks, in order."""
        return list(self._hooks.values())

    async def run_first(self, agent, context, *, root):
        """Run ``agent`` as a nested run of ``root`` before ``root`` starts, in its log.

        NOTE: this is the routing call: the coordinator decides which loop the root run is, so it
        runs first, with ``parent`` and ``root`` set to the root run and no ``parent_step``. The
        root run continues the numbering of the same log and starts with the routing call's usage,
        as ``recover`` counts it.
        """
        log = RunLog(self, root)
        session = RunSession(self, log, RunState(root=root), agent)
        await session.start(context, max_steps=runtime.get("max_steps"), parent=root, root=root)
        result = await self.drive(session)
        self._sequences[root] = log.sequence
        self._usages[root] = result.usage
        return result

    def _root_session(self, context, agent, loop):
        """Return the session of a new root run, after what ran first for it."""
        log = RunLog(self, context.run_id, self._sequences.pop(context.run_id, 0))
        state = RunState(root=context.run_id, usage=self._usages.pop(context.run_id, Usage()))
        return RunSession(self, log, state, agent, loop)

    async def run(self, agent, context, *, max_steps=None, loop=None):
        """Run ``agent`` from ``context`` until it stops."""
        session = self._root_session(context, agent, loop)
        await session.start(context, max_steps=max_steps or runtime.get("max_steps"))
        return await self.drive(session)

    @classmethod
    async def replay(cls, store, run_id, *, replayed=None, workspace=None):
        """Rerun a stored run and its nested runs offline; a difference raises ``ReplayError``."""
        return await replay_run(cls, store, run_id, replayed=replayed, workspace=workspace)

    async def drive(self, session):
        """Run steps until one reason stops the run, then end it.

        NOTE: any exception ends the run with ``error``, not only an ``gd.errors`` class, because a
        provider made by the backend raises its own errors and a client must see the run end. The
        log and ``on_error`` hold the class and message, and a dying process (a ``BaseException``)
        is not caught, so it can be recovered. A part that is not built yet ends the run with
        ``not_implemented`` instead.
        """
        try:
            stop = await self._steps(session)
        except Exception as error:
            await session.report_error(error, where="engine")
            reason = "not_implemented" if isinstance(error, NotImplementedYet) else "error"
            stop = Stop(reason, str(error), is_crash=reason == "error")
        return await self.end(session, stop)

    async def decline(self, loop, context, error):
        """Log a run of a loop that is not built yet, so a client sees it start and end."""
        session = self._root_session(context, loop.agent, loop)
        await session.start(context, max_steps=runtime.get("max_steps"))
        await session.report_error(error, where=f"loop {loop.name}")
        return await self.end(session, Stop("not_implemented", str(error)))

    async def _steps(self, session):
        """Run steps until one returns a stop or the step limit is reached."""
        state = session.state
        if state.has_answer and not state.in_step:
            return Stop(state.stop_reason, answer=state.answer)
        while state.in_step or state.step < state.max_steps:
            stop = await run_step(session, session.agent)
            if stop is not None:
                return stop
        return Stop("step_limit", f"stopped after {state.step} steps")

    async def end(self, session, stop):
        """Close the sandbox and log the end, unless the run only pauses."""
        await session.log.flush()
        await session.close_sandbox()
        if stop.reason == "request":
            return run_result(session, stop)
        if is_limit_stop(session, stop):
            stop = await self._answer_from_record(session, stop)
        await session.emit(
            RunFinished,
            status=status_of(stop.reason),
            stop_reason=stop.reason,
            message=stop.message,
            answer=stop.answer,
        )
        await session.save_problem()
        return run_result(session, stop)

    async def _answer_from_record(self, session, stop):
        """Give a run that a limit stopped the answer its record makes, streamed like any answer."""
        text = await partial_answer(session, stop)
        await session.stream_answer(text)
        return Stop(stop.reason, stop.message, answer=text)

    async def resume(self, run_id, request_id=None, answer=None, *, agent=None, loop=None):
        """Continue a run from its events, in any process.

        With ``request_id`` and ``answer`` it settles the pending request. Without them it
        continues a run whose process died. ``agent`` defaults to a new instance of the stored
        class, and ``loop`` receives its stored state.
        """
        state = recover(self.store.load_events(run_id), run_id)
        if state.status != "running":
            raise RunError(f"resume: run = {state.run_id}; it already ended as {state.status}")
        if loop is not None:
            loop.load_state_dict(state.loop_state)
        agent = agent or agent_class(state)()
        agent.load_loop_state(state.loop_state)
        with runtime.settings(**state.settings):
            log = RunLog(self, state.root, state.sequence)
            session = RunSession(self, log, state, agent, loop)
            return await self.proceed(session, request_id, answer)

    async def proceed(self, session, request_id, answer):
        """Settle what the run stopped on, then drive it on."""
        state = session.state
        if state.pending is not None:
            stop = await self._answer(session, request_id, answer)
            if stop is not None:
                return await self.end(session, stop)
            return await self.drive(session)
        if request_id is not None:
            raise RequestError(
                f"resume: request = {request_id!r}; it is unknown or already answered"
            )
        await end_orphans(session)
        await settle_interrupted(session, session.agent)
        return await self.drive(session)

    async def _answer(self, session, request_id, answer):
        """Settle the pending request; return a stop when that ends or pauses the run."""
        pending = session.state.pending
        if pending.child is not None:
            return await answer_child(session, pending, request_id, answer)
        if request_id != pending.request.id:
            raise RequestError(f"resume: request = {request_id!r}; expected {pending.request.id!r}")
        answer = validate_answer(pending.request, answer)
        fields = dict(
            index=session.state.step,
            rule="user",
            point=pending.point,
            call_id=pending.call.id if pending.call else None,
            tool=pending.call.name if pending.call else None,
            request=pending.request,
        )
        if "text" in answer:
            return await self._take_text(session, pending, answer["text"], fields)
        if answer["approved"]:
            await session.emit(PermissionDecided, decision="allow", **fields)
            return None
        reason = answer.get("reason") or "denied by the user"
        await session.emit(PermissionDecided, decision="deny", reason=reason, **fields)
        return await self._take_denial(session, pending, reason)

    async def _take_text(self, session, pending, text, fields):
        """Make a user's reply the tool result, or a message at the other points."""
        decision = "answer" if pending.point == "tool" else "allow"
        await session.emit(PermissionDecided, decision=decision, **fields)
        if pending.point == "tool":
            result = text_result(pending.call, text)
            await record_result(session, pending.call, result, source="answer")
            return None
        await session.emit(ToolRecorded, index=session.state.step, output=text, source="answer")
        return None

    async def _take_denial(self, session, pending, reason):
        """Apply a user's denial at the point the run paused."""
        if pending.point == "llm":
            return Stop("denied", reason)
        if pending.call is None:
            await session.emit(
                ToolRecorded,
                index=session.state.step,
                output=reason,
                is_error=True,
                source="denied",
                feedback="finish",
            )
            return None
        result = text_result(pending.call, reason, is_error=True)
        await record_result(session, pending.call, result, source="denied")
        return None
